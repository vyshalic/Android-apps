package com.example.b_wi.sample1;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

public class DatabaseHelper extends SQLiteOpenHelper {
    private static final int DATABASE_VERSION = 1;

    // Database Name
    private static final String DATABASE_NAME = "login.db";

    public DatabaseHelper(Context context, String name, SQLiteDatabase.CursorFactory factory, int version) {
        super(context, DATABASE_NAME, factory, DATABASE_VERSION);
    }

    // Table Names
    private static final String USER_TABLE = "user1";


    private static final String CREATE_TABLE_ACCOUNTS = "CREATE TABLE "
            +USER_TABLE + "( UserId INTEGER PRIMARY KEY AUTOINCREMENT,password TEXT, phone TEXT)";


    @Override
    public void onCreate(SQLiteDatabase db) {
        db.execSQL(CREATE_TABLE_ACCOUNTS);
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {

    }

    public void addUser(User s){
        ContentValues c = new ContentValues();
        c.put("password",s.getPwd());
        c.put("phone",s.getPhone());
        SQLiteDatabase d = this.getWritableDatabase();
        d.insert("user1",null,c);

    }

    public User findHandler(String em){
        String find = "SELECT * FROM user1 WHERE phone = "+"'"+ em+"'";

        SQLiteDatabase f = this.getWritableDatabase();
        Cursor c = f.rawQuery(find,null);
        //create a User object to store the data that you are sending
        User User = new User();
        //checks if the result contains any valid row using moveToFirst func
        if(c.moveToFirst()) {
            c.moveToFirst();
            User.setUid(Integer.parseInt(c.getString(0)));
            User.setPhone(c.getString(2));
            c.close();
        }
        else {
            User=null;
        }
        return User;
    }
}